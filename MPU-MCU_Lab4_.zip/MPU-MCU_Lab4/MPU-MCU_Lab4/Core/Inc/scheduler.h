#ifndef INC_SCHEDULER_H_
#define INC_SCHEDULER_H_

#include <stdint.h>
#include <stddef.h>

#define SCH_MAX_TASKS   40
#define NO_TASK_ID      0

#define RETURN_NORMAL   1
#define RETURN_ERROR    0

// Error codes
#define ERROR_SCH_TOO_MANY_TASKS        1
#define ERROR_SCH_CANNOT_DELETE_TASK    2

typedef struct {
    void (*pTask)(void); // Pointer to the task (must be 'void (void)' function)
    uint32_t Delay;      // Initial delay (in ticks)
    uint32_t Period;     // Period (in ticks) between executions, 0 = one-shot
    uint8_t  RunMe;      // Incremented/set when task is due to execute
    uint32_t TaskID;     // Identifier of the task
    uint32_t target_tick;// Absolute system tick deadline (for zero-drift O(1) scheduling)
} sTask;

extern uint8_t Error_code_G;

// Core functions required by Lab 4
void     SCH_Init(void);
void     SCH_Update(void);
void     SCH_Dispatch_Tasks(void);
uint32_t SCH_Add_Task(void (*pFunction)(void), uint32_t DELAY, uint32_t PERIOD);
uint8_t  SCH_Delete_Task(uint32_t taskID);

// Accurate timestamp function (milliseconds, 10ms resolution)
uint32_t get_time(void);

#endif /* INC_SCHEDULER_H_ */


#include "scheduler.h"
#include "main.h"

static sTask SCH_tasks_G[SCH_MAX_TASKS];
static volatile uint8_t SCH_count = 0;
static uint32_t next_task_id = 1;
static volatile uint32_t system_ticks = 0;
static uint32_t current_task_timestamp = 0;

uint8_t Error_code_G = 0;

static uint32_t get_new_task_id(void) {
    uint32_t new_id = next_task_id;
    next_task_id++;

    if (next_task_id == NO_TASK_ID)
        next_task_id = 1;

    return new_id;
}

static void sch_insert_sorted(sTask task) {
    if (SCH_count == SCH_MAX_TASKS) {
        Error_code_G = ERROR_SCH_TOO_MANY_TASKS;
        return;
    }

    uint8_t pos = 0;

    while (pos < SCH_count) {
        if ((int32_t)(task.target_tick -
            SCH_tasks_G[pos].target_tick) < 0)
            break;

        pos++;
    }

    for (uint8_t k = SCH_count; k > pos; --k) {
        SCH_tasks_G[k] = SCH_tasks_G[k - 1];
    }

    SCH_tasks_G[pos] = task;
    ++SCH_count;
}

void SCH_Init(void) {
    __disable_irq();

    SCH_count = 0;
    system_ticks = 0;
    current_task_timestamp = 0;
    Error_code_G = 0;

    for (uint8_t k = 0; k < SCH_MAX_TASKS; ++k) {
        SCH_tasks_G[k].pTask = NULL;
        SCH_tasks_G[k].Delay = 0;
        SCH_tasks_G[k].Period = 0;
        SCH_tasks_G[k].RunMe = 0;
        SCH_tasks_G[k].TaskID = NO_TASK_ID;
        SCH_tasks_G[k].target_tick = 0;
    }

    __enable_irq();
}

uint32_t SCH_Add_Task(void (*pFunction)(void),
                      uint32_t DELAY,
                      uint32_t PERIOD) {
    if (pFunction == NULL || SCH_count >= SCH_MAX_TASKS) {
        Error_code_G = ERROR_SCH_TOO_MANY_TASKS;
        return NO_TASK_ID;
    }

    __disable_irq();

    sTask task;
    uint32_t id = get_new_task_id();

    task.pTask = pFunction;
    task.Delay = DELAY;
    task.Period = PERIOD;
    task.RunMe = 0;
    task.TaskID = id;
    task.target_tick = system_ticks + DELAY;

    sch_insert_sorted(task);

    __enable_irq();

    return id;
}

uint8_t SCH_Delete_Task(uint32_t taskID) {
    if (taskID == NO_TASK_ID || SCH_count == 0) {
        Error_code_G = ERROR_SCH_CANNOT_DELETE_TASK;
        return RETURN_ERROR;
    }

    __disable_irq();

    for (uint8_t pos = 0; pos < SCH_count; ++pos) {
        if (SCH_tasks_G[pos].TaskID != taskID)
            continue;

        for (uint8_t k = pos; k + 1 < SCH_count; ++k) {
            SCH_tasks_G[k] = SCH_tasks_G[k + 1];
        }

        --SCH_count;

        SCH_tasks_G[SCH_count].pTask = NULL;
        SCH_tasks_G[SCH_count].Delay = 0;
        SCH_tasks_G[SCH_count].Period = 0;
        SCH_tasks_G[SCH_count].RunMe = 0;
        SCH_tasks_G[SCH_count].TaskID = NO_TASK_ID;
        SCH_tasks_G[SCH_count].target_tick = 0;

        __enable_irq();
        return RETURN_NORMAL;
    }

    __enable_irq();

    Error_code_G = ERROR_SCH_CANNOT_DELETE_TASK;
    return RETURN_ERROR;
}

void SCH_Update(void) {
    ++system_ticks;

    if (SCH_count == 0)
        return;

    if ((int32_t)(system_ticks -
        SCH_tasks_G[0].target_tick) >= 0) {
        SCH_tasks_G[0].RunMe = 1;
    }
}

void SCH_Dispatch_Tasks(void) {
    while (SCH_count > 0 &&
           (int32_t)(system_ticks -
           SCH_tasks_G[0].target_tick) >= 0) {

        __disable_irq();

        sTask running_task = SCH_tasks_G[0];

        for (uint8_t k = 1; k < SCH_count; ++k) {
            SCH_tasks_G[k - 1] = SCH_tasks_G[k];
        }

        --SCH_count;

        SCH_tasks_G[SCH_count].pTask = NULL;
        SCH_tasks_G[SCH_count].Delay = 0;
        SCH_tasks_G[SCH_count].Period = 0;
        SCH_tasks_G[SCH_count].RunMe = 0;
        SCH_tasks_G[SCH_count].TaskID = NO_TASK_ID;
        SCH_tasks_G[SCH_count].target_tick = 0;

        current_task_timestamp = running_task.target_tick * 10;

        __enable_irq();

        if (running_task.pTask != NULL) {
            running_task.pTask();
        }

        if (running_task.Period != 0) {
            running_task.target_tick += running_task.Period;
            running_task.RunMe = 0;

            __disable_irq();
            sch_insert_sorted(running_task);
            __enable_irq();
        }
    }

    current_task_timestamp = 0;
}

uint32_t get_time(void) {
    return (current_task_timestamp != 0)
        ? current_task_timestamp
        : system_ticks * 10;
}
